import Link from "next/link";
import { AppStoreBadgeLink } from "./AppStoreBadgeLink";
import { appStoreHref, footerSections } from "./SiteNavigation";

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="site-footer__inner">
        <div className="site-footer__brand">
          <Link className="site-brand site-brand--footer" href="/" data-nav-id="footer_home">
            <img
              className="site-brand__mark"
              src="/icon.png"
              alt=""
              width={34}
              height={34}
              aria-hidden="true"
            />
            <span className="site-brand__name">あんぴッチ</span>
          </Link>
          <AppStoreBadgeLink className="site-footer__cta" href={appStoreHref} navId="nav_appstore" />
        </div>

        <nav className="site-footer__nav" aria-label="フッター">
          {footerSections.map((section) => (
            <section className="site-footer__section" key={section.title}>
              <h2>{section.title}</h2>
              <ul>
                {section.links.map((link) => (
                  <li key={link.href}>
                    <Link href={link.href} data-nav-id={link.navId}>
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </nav>
      </div>
    </footer>
  );
}
